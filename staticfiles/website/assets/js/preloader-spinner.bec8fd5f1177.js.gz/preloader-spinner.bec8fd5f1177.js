$(document).ready(function() {
    window.onload = function () {
        $('#spinner').fadeOut(500, function(){
            $('#spinner').remove();
        } );
    }
});

